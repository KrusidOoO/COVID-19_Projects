﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uge_14___miniprojekt__Pizzeria_
{
    public class TaskMaster
    {
        public string temporaryString1;
        public string temporaryString2;
        public string temporaryString3;
        public int finalPrice=0;

        public string Order="";





    }
}
