﻿namespace Uge_14___miniprojekt__Pizzeria_
{
    partial class Ingredients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Options_Header_Label = new System.Windows.Forms.Label();
            this.Thickness_Options_Header = new System.Windows.Forms.Label();
            this.Topping_Options_Header_Label = new System.Windows.Forms.Label();
            this.Chosen_Pizza_Number_Label = new System.Windows.Forms.Label();
            this.Chosen_Pizza_Description_Label = new System.Windows.Forms.Label();
            this.Chosen_Pizza_Name_Label = new System.Windows.Forms.Label();
            this.Thickness_RButton2 = new System.Windows.Forms.RadioButton();
            this.Thickness_RButton3 = new System.Windows.Forms.RadioButton();
            this.Thickness_RButton1 = new System.Windows.Forms.RadioButton();
            this.Topping_Options1 = new System.Windows.Forms.CheckBox();
            this.Topping_Options2 = new System.Windows.Forms.CheckBox();
            this.Topping_Options3 = new System.Windows.Forms.CheckBox();
            this.Topping_Options4 = new System.Windows.Forms.CheckBox();
            this.Topping_Options5 = new System.Windows.Forms.CheckBox();
            this.Topping_Options6 = new System.Windows.Forms.CheckBox();
            this.Topping_Options7 = new System.Windows.Forms.CheckBox();
            this.Topping_Options8 = new System.Windows.Forms.CheckBox();
            this.Topping_Options9 = new System.Windows.Forms.CheckBox();
            this.Topping_Options10 = new System.Windows.Forms.CheckBox();
            this.Topping_Options11 = new System.Windows.Forms.CheckBox();
            this.Topping_Options12 = new System.Windows.Forms.CheckBox();
            this.Topping_Options13 = new System.Windows.Forms.CheckBox();
            this.Topping_Options14 = new System.Windows.Forms.CheckBox();
            this.Topping_Options15 = new System.Windows.Forms.CheckBox();
            this.Topping_Options16 = new System.Windows.Forms.CheckBox();
            this.Topping_Options17 = new System.Windows.Forms.CheckBox();
            this.Topping_Options18 = new System.Windows.Forms.CheckBox();
            this.Topping_Options19 = new System.Windows.Forms.CheckBox();
            this.Topping_Options20 = new System.Windows.Forms.CheckBox();
            this.Done_Selecting_Button = new System.Windows.Forms.Button();
            this.Price_In_Total_Label = new System.Windows.Forms.Label();
            this.Price_In_Total_Numbers_Label = new System.Windows.Forms.Label();
            this.Topping_Options_Price1 = new System.Windows.Forms.Label();
            this.Topping_Options_Price2 = new System.Windows.Forms.Label();
            this.Topping_Options_Price3 = new System.Windows.Forms.Label();
            this.Topping_Options_Price4 = new System.Windows.Forms.Label();
            this.Topping_Options_Price5 = new System.Windows.Forms.Label();
            this.Topping_Options_Price6 = new System.Windows.Forms.Label();
            this.Topping_Options_Price7 = new System.Windows.Forms.Label();
            this.Topping_Options_Price8 = new System.Windows.Forms.Label();
            this.Topping_Options_Price9 = new System.Windows.Forms.Label();
            this.Topping_Options_Price10 = new System.Windows.Forms.Label();
            this.Topping_Options_Price11 = new System.Windows.Forms.Label();
            this.Topping_Options_Price12 = new System.Windows.Forms.Label();
            this.Topping_Options_Price13 = new System.Windows.Forms.Label();
            this.Topping_Options_Price14 = new System.Windows.Forms.Label();
            this.Topping_Options_Price15 = new System.Windows.Forms.Label();
            this.Topping_Options_Price16 = new System.Windows.Forms.Label();
            this.Topping_Options_Price17 = new System.Windows.Forms.Label();
            this.Topping_Options_Price18 = new System.Windows.Forms.Label();
            this.Topping_Options_Price19 = new System.Windows.Forms.Label();
            this.Topping_Options_Price20 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Order_Ingredients_Label = new System.Windows.Forms.Label();
            this.Checkout_Header_Label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Options_Header_Label
            // 
            this.Options_Header_Label.AutoSize = true;
            this.Options_Header_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options_Header_Label.Location = new System.Drawing.Point(299, 19);
            this.Options_Header_Label.Name = "Options_Header_Label";
            this.Options_Header_Label.Size = new System.Drawing.Size(197, 29);
            this.Options_Header_Label.TabIndex = 1;
            this.Options_Header_Label.Text = "Valgmuligheder";
            // 
            // Thickness_Options_Header
            // 
            this.Thickness_Options_Header.AutoSize = true;
            this.Thickness_Options_Header.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Thickness_Options_Header.Location = new System.Drawing.Point(247, 98);
            this.Thickness_Options_Header.Name = "Thickness_Options_Header";
            this.Thickness_Options_Header.Size = new System.Drawing.Size(91, 20);
            this.Thickness_Options_Header.TabIndex = 4;
            this.Thickness_Options_Header.Text = "Vælg bund:";
            // 
            // Topping_Options_Header_Label
            // 
            this.Topping_Options_Header_Label.AutoSize = true;
            this.Topping_Options_Header_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Topping_Options_Header_Label.Location = new System.Drawing.Point(84, 25);
            this.Topping_Options_Header_Label.Name = "Topping_Options_Header_Label";
            this.Topping_Options_Header_Label.Size = new System.Drawing.Size(142, 24);
            this.Topping_Options_Header_Label.TabIndex = 5;
            this.Topping_Options_Header_Label.Text = "Vælg ekstra fyld";
            // 
            // Chosen_Pizza_Number_Label
            // 
            this.Chosen_Pizza_Number_Label.AutoSize = true;
            this.Chosen_Pizza_Number_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chosen_Pizza_Number_Label.Location = new System.Drawing.Point(38, 56);
            this.Chosen_Pizza_Number_Label.Name = "Chosen_Pizza_Number_Label";
            this.Chosen_Pizza_Number_Label.Size = new System.Drawing.Size(25, 24);
            this.Chosen_Pizza_Number_Label.TabIndex = 6;
            this.Chosen_Pizza_Number_Label.Text = "0.";
            // 
            // Chosen_Pizza_Description_Label
            // 
            this.Chosen_Pizza_Description_Label.AutoSize = true;
            this.Chosen_Pizza_Description_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chosen_Pizza_Description_Label.Location = new System.Drawing.Point(70, 83);
            this.Chosen_Pizza_Description_Label.Name = "Chosen_Pizza_Description_Label";
            this.Chosen_Pizza_Description_Label.Size = new System.Drawing.Size(152, 17);
            this.Chosen_Pizza_Description_Label.TabIndex = 7;
            this.Chosen_Pizza_Description_Label.Text = "Valgt pizza beskrivelse";
            // 
            // Chosen_Pizza_Name_Label
            // 
            this.Chosen_Pizza_Name_Label.AutoSize = true;
            this.Chosen_Pizza_Name_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chosen_Pizza_Name_Label.Location = new System.Drawing.Point(69, 56);
            this.Chosen_Pizza_Name_Label.Name = "Chosen_Pizza_Name_Label";
            this.Chosen_Pizza_Name_Label.Size = new System.Drawing.Size(125, 20);
            this.Chosen_Pizza_Name_Label.TabIndex = 8;
            this.Chosen_Pizza_Name_Label.Text = "Valgt pizza navn";
            // 
            // Thickness_RButton2
            // 
            this.Thickness_RButton2.AutoSize = true;
            this.Thickness_RButton2.Location = new System.Drawing.Point(360, 101);
            this.Thickness_RButton2.Name = "Thickness_RButton2";
            this.Thickness_RButton2.Size = new System.Drawing.Size(89, 17);
            this.Thickness_RButton2.TabIndex = 9;
            this.Thickness_RButton2.Text = "Dobbelt bund";
            this.Thickness_RButton2.UseVisualStyleBackColor = true;
            this.Thickness_RButton2.CheckedChanged += new System.EventHandler(this.Thickness_RButton2_CheckedChanged);
            // 
            // Thickness_RButton3
            // 
            this.Thickness_RButton3.AutoSize = true;
            this.Thickness_RButton3.Location = new System.Drawing.Point(360, 124);
            this.Thickness_RButton3.Name = "Thickness_RButton3";
            this.Thickness_RButton3.Size = new System.Drawing.Size(73, 17);
            this.Thickness_RButton3.TabIndex = 10;
            this.Thickness_RButton3.Text = "Deep Pan";
            this.Thickness_RButton3.UseVisualStyleBackColor = true;
            this.Thickness_RButton3.CheckedChanged += new System.EventHandler(this.Thickness_RButton3_CheckedChanged);
            // 
            // Thickness_RButton1
            // 
            this.Thickness_RButton1.AutoSize = true;
            this.Thickness_RButton1.Location = new System.Drawing.Point(360, 78);
            this.Thickness_RButton1.Name = "Thickness_RButton1";
            this.Thickness_RButton1.Size = new System.Drawing.Size(72, 17);
            this.Thickness_RButton1.TabIndex = 11;
            this.Thickness_RButton1.Text = "Almindelig";
            this.Thickness_RButton1.UseVisualStyleBackColor = true;
            this.Thickness_RButton1.CheckedChanged += new System.EventHandler(this.Thickness_RButton1_CheckedChanged);
            // 
            // Topping_Options1
            // 
            this.Topping_Options1.AutoSize = true;
            this.Topping_Options1.Location = new System.Drawing.Point(86, 103);
            this.Topping_Options1.Name = "Topping_Options1";
            this.Topping_Options1.Size = new System.Drawing.Size(62, 17);
            this.Topping_Options1.TabIndex = 12;
            this.Topping_Options1.Text = "Ananas";
            this.Topping_Options1.UseVisualStyleBackColor = true;
            this.Topping_Options1.CheckedChanged += new System.EventHandler(this.Topping_Options1_CheckedChanged);
            // 
            // Topping_Options2
            // 
            this.Topping_Options2.AutoSize = true;
            this.Topping_Options2.Location = new System.Drawing.Point(86, 126);
            this.Topping_Options2.Name = "Topping_Options2";
            this.Topping_Options2.Size = new System.Drawing.Size(64, 17);
            this.Topping_Options2.TabIndex = 13;
            this.Topping_Options2.Text = "Artiskok";
            this.Topping_Options2.UseVisualStyleBackColor = true;
            this.Topping_Options2.CheckedChanged += new System.EventHandler(this.Topping_Options2_CheckedChanged);
            // 
            // Topping_Options3
            // 
            this.Topping_Options3.AutoSize = true;
            this.Topping_Options3.Location = new System.Drawing.Point(86, 149);
            this.Topping_Options3.Name = "Topping_Options3";
            this.Topping_Options3.Size = new System.Drawing.Size(70, 17);
            this.Topping_Options3.TabIndex = 14;
            this.Topping_Options3.Text = "Asparges";
            this.Topping_Options3.UseVisualStyleBackColor = true;
            this.Topping_Options3.CheckedChanged += new System.EventHandler(this.Topping_Options3_CheckedChanged);
            // 
            // Topping_Options4
            // 
            this.Topping_Options4.AutoSize = true;
            this.Topping_Options4.Location = new System.Drawing.Point(86, 172);
            this.Topping_Options4.Name = "Topping_Options4";
            this.Topping_Options4.Size = new System.Drawing.Size(57, 17);
            this.Topping_Options4.TabIndex = 15;
            this.Topping_Options4.Text = "Bacon";
            this.Topping_Options4.UseVisualStyleBackColor = true;
            this.Topping_Options4.CheckedChanged += new System.EventHandler(this.Topping_Options4_CheckedChanged);
            // 
            // Topping_Options5
            // 
            this.Topping_Options5.AutoSize = true;
            this.Topping_Options5.Location = new System.Drawing.Point(86, 195);
            this.Topping_Options5.Name = "Topping_Options5";
            this.Topping_Options5.Size = new System.Drawing.Size(96, 17);
            this.Topping_Options5.TabIndex = 16;
            this.Topping_Options5.Text = "Bernaisesauce";
            this.Topping_Options5.UseVisualStyleBackColor = true;
            this.Topping_Options5.CheckedChanged += new System.EventHandler(this.Topping_Options5_CheckedChanged);
            // 
            // Topping_Options6
            // 
            this.Topping_Options6.AutoSize = true;
            this.Topping_Options6.Location = new System.Drawing.Point(86, 218);
            this.Topping_Options6.Name = "Topping_Options6";
            this.Topping_Options6.Size = new System.Drawing.Size(85, 17);
            this.Topping_Options6.TabIndex = 17;
            this.Topping_Options6.Text = "Champignon";
            this.Topping_Options6.UseVisualStyleBackColor = true;
            this.Topping_Options6.CheckedChanged += new System.EventHandler(this.Topping_Options6_CheckedChanged);
            // 
            // Topping_Options7
            // 
            this.Topping_Options7.AutoSize = true;
            this.Topping_Options7.Location = new System.Drawing.Point(86, 241);
            this.Topping_Options7.Name = "Topping_Options7";
            this.Topping_Options7.Size = new System.Drawing.Size(45, 17);
            this.Topping_Options7.TabIndex = 18;
            this.Topping_Options7.Text = "Chili";
            this.Topping_Options7.UseVisualStyleBackColor = true;
            this.Topping_Options7.CheckedChanged += new System.EventHandler(this.Topping_Options7_CheckedChanged);
            // 
            // Topping_Options8
            // 
            this.Topping_Options8.AutoSize = true;
            this.Topping_Options8.Location = new System.Drawing.Point(86, 264);
            this.Topping_Options8.Name = "Topping_Options8";
            this.Topping_Options8.Size = new System.Drawing.Size(92, 17);
            this.Topping_Options8.TabIndex = 19;
            this.Topping_Options8.Text = "Cocktailpølser";
            this.Topping_Options8.UseVisualStyleBackColor = true;
            this.Topping_Options8.CheckedChanged += new System.EventHandler(this.Topping_Options8_CheckedChanged);
            // 
            // Topping_Options9
            // 
            this.Topping_Options9.AutoSize = true;
            this.Topping_Options9.Location = new System.Drawing.Point(86, 287);
            this.Topping_Options9.Name = "Topping_Options9";
            this.Topping_Options9.Size = new System.Drawing.Size(73, 17);
            this.Topping_Options9.TabIndex = 20;
            this.Topping_Options9.Text = "Ekstra ost";
            this.Topping_Options9.UseVisualStyleBackColor = true;
            this.Topping_Options9.CheckedChanged += new System.EventHandler(this.Topping_Options9_CheckedChanged);
            // 
            // Topping_Options10
            // 
            this.Topping_Options10.AutoSize = true;
            this.Topping_Options10.Location = new System.Drawing.Point(86, 310);
            this.Topping_Options10.Name = "Topping_Options10";
            this.Topping_Options10.Size = new System.Drawing.Size(61, 17);
            this.Topping_Options10.TabIndex = 21;
            this.Topping_Options10.Text = "Fetaost";
            this.Topping_Options10.UseVisualStyleBackColor = true;
            this.Topping_Options10.CheckedChanged += new System.EventHandler(this.Topping_Options10_CheckedChanged);
            // 
            // Topping_Options11
            // 
            this.Topping_Options11.AutoSize = true;
            this.Topping_Options11.Location = new System.Drawing.Point(511, 105);
            this.Topping_Options11.Name = "Topping_Options11";
            this.Topping_Options11.Size = new System.Drawing.Size(77, 17);
            this.Topping_Options11.TabIndex = 22;
            this.Topping_Options11.Text = "Frisk tomat";
            this.Topping_Options11.UseVisualStyleBackColor = true;
            this.Topping_Options11.CheckedChanged += new System.EventHandler(this.Topping_Options11_CheckedChanged);
            // 
            // Topping_Options12
            // 
            this.Topping_Options12.AutoSize = true;
            this.Topping_Options12.Location = new System.Drawing.Point(511, 128);
            this.Topping_Options12.Name = "Topping_Options12";
            this.Topping_Options12.Size = new System.Drawing.Size(80, 17);
            this.Topping_Options12.TabIndex = 23;
            this.Topping_Options12.Text = "Gorgonzola";
            this.Topping_Options12.UseVisualStyleBackColor = true;
            this.Topping_Options12.CheckedChanged += new System.EventHandler(this.Topping_Options12_CheckedChanged);
            // 
            // Topping_Options13
            // 
            this.Topping_Options13.AutoSize = true;
            this.Topping_Options13.Location = new System.Drawing.Point(511, 151);
            this.Topping_Options13.Name = "Topping_Options13";
            this.Topping_Options13.Size = new System.Drawing.Size(79, 17);
            this.Topping_Options13.TabIndex = 24;
            this.Topping_Options13.Text = "Grøn peber";
            this.Topping_Options13.UseVisualStyleBackColor = true;
            this.Topping_Options13.CheckedChanged += new System.EventHandler(this.Topping_Options13_CheckedChanged);
            // 
            // Topping_Options14
            // 
            this.Topping_Options14.AutoSize = true;
            this.Topping_Options14.Location = new System.Drawing.Point(511, 174);
            this.Topping_Options14.Name = "Topping_Options14";
            this.Topping_Options14.Size = new System.Drawing.Size(62, 17);
            this.Topping_Options14.TabIndex = 25;
            this.Topping_Options14.Text = "Hvidløg";
            this.Topping_Options14.UseVisualStyleBackColor = true;
            this.Topping_Options14.CheckedChanged += new System.EventHandler(this.Topping_Options14_CheckedChanged);
            // 
            // Topping_Options15
            // 
            this.Topping_Options15.AutoSize = true;
            this.Topping_Options15.Location = new System.Drawing.Point(511, 197);
            this.Topping_Options15.Name = "Topping_Options15";
            this.Topping_Options15.Size = new System.Drawing.Size(74, 17);
            this.Topping_Options15.TabIndex = 26;
            this.Topping_Options15.Text = "Jalapenos";
            this.Topping_Options15.UseVisualStyleBackColor = true;
            this.Topping_Options15.CheckedChanged += new System.EventHandler(this.Topping_Options15_CheckedChanged);
            // 
            // Topping_Options16
            // 
            this.Topping_Options16.AutoSize = true;
            this.Topping_Options16.Location = new System.Drawing.Point(511, 220);
            this.Topping_Options16.Name = "Topping_Options16";
            this.Topping_Options16.Size = new System.Drawing.Size(57, 17);
            this.Topping_Options16.TabIndex = 27;
            this.Topping_Options16.Text = "Kebab";
            this.Topping_Options16.UseVisualStyleBackColor = true;
            this.Topping_Options16.CheckedChanged += new System.EventHandler(this.Topping_Options16_CheckedChanged);
            // 
            // Topping_Options17
            // 
            this.Topping_Options17.AutoSize = true;
            this.Topping_Options17.Location = new System.Drawing.Point(511, 243);
            this.Topping_Options17.Name = "Topping_Options17";
            this.Topping_Options17.Size = new System.Drawing.Size(74, 17);
            this.Topping_Options17.TabIndex = 28;
            this.Topping_Options17.Text = "Kødsauce";
            this.Topping_Options17.UseVisualStyleBackColor = true;
            this.Topping_Options17.CheckedChanged += new System.EventHandler(this.Topping_Options17_CheckedChanged);
            // 
            // Topping_Options18
            // 
            this.Topping_Options18.AutoSize = true;
            this.Topping_Options18.Location = new System.Drawing.Point(511, 266);
            this.Topping_Options18.Name = "Topping_Options18";
            this.Topping_Options18.Size = new System.Drawing.Size(78, 17);
            this.Topping_Options18.TabIndex = 29;
            this.Topping_Options18.Text = "Krabbekød";
            this.Topping_Options18.UseVisualStyleBackColor = true;
            this.Topping_Options18.CheckedChanged += new System.EventHandler(this.Topping_Options18_CheckedChanged);
            // 
            // Topping_Options19
            // 
            this.Topping_Options19.AutoSize = true;
            this.Topping_Options19.Location = new System.Drawing.Point(511, 289);
            this.Topping_Options19.Name = "Topping_Options19";
            this.Topping_Options19.Size = new System.Drawing.Size(56, 17);
            this.Topping_Options19.TabIndex = 30;
            this.Topping_Options19.Text = "Kylling";
            this.Topping_Options19.UseVisualStyleBackColor = true;
            this.Topping_Options19.CheckedChanged += new System.EventHandler(this.Topping_Options19_CheckedChanged);
            // 
            // Topping_Options20
            // 
            this.Topping_Options20.AutoSize = true;
            this.Topping_Options20.Location = new System.Drawing.Point(511, 312);
            this.Topping_Options20.Name = "Topping_Options20";
            this.Topping_Options20.Size = new System.Drawing.Size(44, 17);
            this.Topping_Options20.TabIndex = 31;
            this.Topping_Options20.Text = "Løg";
            this.Topping_Options20.UseVisualStyleBackColor = true;
            this.Topping_Options20.CheckedChanged += new System.EventHandler(this.Topping_Options20_CheckedChanged);
            // 
            // Done_Selecting_Button
            // 
            this.Done_Selecting_Button.Location = new System.Drawing.Point(156, 431);
            this.Done_Selecting_Button.Name = "Done_Selecting_Button";
            this.Done_Selecting_Button.Size = new System.Drawing.Size(91, 41);
            this.Done_Selecting_Button.TabIndex = 32;
            this.Done_Selecting_Button.Text = "Færdig";
            this.Done_Selecting_Button.UseVisualStyleBackColor = true;
            this.Done_Selecting_Button.Click += new System.EventHandler(this.Done_Selecting_Button_Click);
            // 
            // Price_In_Total_Label
            // 
            this.Price_In_Total_Label.AutoSize = true;
            this.Price_In_Total_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_In_Total_Label.Location = new System.Drawing.Point(152, 381);
            this.Price_In_Total_Label.Name = "Price_In_Total_Label";
            this.Price_In_Total_Label.Size = new System.Drawing.Size(44, 20);
            this.Price_In_Total_Label.TabIndex = 33;
            this.Price_In_Total_Label.Text = "Pris:";
            // 
            // Price_In_Total_Numbers_Label
            // 
            this.Price_In_Total_Numbers_Label.AutoSize = true;
            this.Price_In_Total_Numbers_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_In_Total_Numbers_Label.Location = new System.Drawing.Point(212, 381);
            this.Price_In_Total_Numbers_Label.Name = "Price_In_Total_Numbers_Label";
            this.Price_In_Total_Numbers_Label.Size = new System.Drawing.Size(18, 20);
            this.Price_In_Total_Numbers_Label.TabIndex = 34;
            this.Price_In_Total_Numbers_Label.Text = "0";
            // 
            // Topping_Options_Price1
            // 
            this.Topping_Options_Price1.AutoSize = true;
            this.Topping_Options_Price1.Location = new System.Drawing.Point(236, 104);
            this.Topping_Options_Price1.Name = "Topping_Options_Price1";
            this.Topping_Options_Price1.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price1.TabIndex = 35;
            this.Topping_Options_Price1.Text = "5,00 kr";
            // 
            // Topping_Options_Price2
            // 
            this.Topping_Options_Price2.AutoSize = true;
            this.Topping_Options_Price2.Location = new System.Drawing.Point(236, 127);
            this.Topping_Options_Price2.Name = "Topping_Options_Price2";
            this.Topping_Options_Price2.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price2.TabIndex = 36;
            this.Topping_Options_Price2.Text = "5,00 kr";
            // 
            // Topping_Options_Price3
            // 
            this.Topping_Options_Price3.AutoSize = true;
            this.Topping_Options_Price3.Location = new System.Drawing.Point(236, 150);
            this.Topping_Options_Price3.Name = "Topping_Options_Price3";
            this.Topping_Options_Price3.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price3.TabIndex = 37;
            this.Topping_Options_Price3.Text = "5,00 kr";
            // 
            // Topping_Options_Price4
            // 
            this.Topping_Options_Price4.AutoSize = true;
            this.Topping_Options_Price4.Location = new System.Drawing.Point(236, 173);
            this.Topping_Options_Price4.Name = "Topping_Options_Price4";
            this.Topping_Options_Price4.Size = new System.Drawing.Size(46, 13);
            this.Topping_Options_Price4.TabIndex = 38;
            this.Topping_Options_Price4.Text = "10,00 kr";
            // 
            // Topping_Options_Price5
            // 
            this.Topping_Options_Price5.AutoSize = true;
            this.Topping_Options_Price5.Location = new System.Drawing.Point(236, 196);
            this.Topping_Options_Price5.Name = "Topping_Options_Price5";
            this.Topping_Options_Price5.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price5.TabIndex = 39;
            this.Topping_Options_Price5.Text = "5,00 kr";
            // 
            // Topping_Options_Price6
            // 
            this.Topping_Options_Price6.AutoSize = true;
            this.Topping_Options_Price6.Location = new System.Drawing.Point(236, 219);
            this.Topping_Options_Price6.Name = "Topping_Options_Price6";
            this.Topping_Options_Price6.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price6.TabIndex = 40;
            this.Topping_Options_Price6.Text = "5,00 kr";
            // 
            // Topping_Options_Price7
            // 
            this.Topping_Options_Price7.AutoSize = true;
            this.Topping_Options_Price7.Location = new System.Drawing.Point(236, 242);
            this.Topping_Options_Price7.Name = "Topping_Options_Price7";
            this.Topping_Options_Price7.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price7.TabIndex = 41;
            this.Topping_Options_Price7.Text = "5,00 kr";
            // 
            // Topping_Options_Price8
            // 
            this.Topping_Options_Price8.AutoSize = true;
            this.Topping_Options_Price8.Location = new System.Drawing.Point(236, 265);
            this.Topping_Options_Price8.Name = "Topping_Options_Price8";
            this.Topping_Options_Price8.Size = new System.Drawing.Size(46, 13);
            this.Topping_Options_Price8.TabIndex = 42;
            this.Topping_Options_Price8.Text = "10,00 kr";
            // 
            // Topping_Options_Price9
            // 
            this.Topping_Options_Price9.AutoSize = true;
            this.Topping_Options_Price9.Location = new System.Drawing.Point(236, 288);
            this.Topping_Options_Price9.Name = "Topping_Options_Price9";
            this.Topping_Options_Price9.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price9.TabIndex = 43;
            this.Topping_Options_Price9.Text = "5,00 kr";
            // 
            // Topping_Options_Price10
            // 
            this.Topping_Options_Price10.AutoSize = true;
            this.Topping_Options_Price10.Location = new System.Drawing.Point(236, 311);
            this.Topping_Options_Price10.Name = "Topping_Options_Price10";
            this.Topping_Options_Price10.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price10.TabIndex = 44;
            this.Topping_Options_Price10.Text = "5,00 kr";
            // 
            // Topping_Options_Price11
            // 
            this.Topping_Options_Price11.AutoSize = true;
            this.Topping_Options_Price11.Location = new System.Drawing.Point(636, 104);
            this.Topping_Options_Price11.Name = "Topping_Options_Price11";
            this.Topping_Options_Price11.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price11.TabIndex = 45;
            this.Topping_Options_Price11.Text = "5,00 kr";
            // 
            // Topping_Options_Price12
            // 
            this.Topping_Options_Price12.AutoSize = true;
            this.Topping_Options_Price12.Location = new System.Drawing.Point(636, 127);
            this.Topping_Options_Price12.Name = "Topping_Options_Price12";
            this.Topping_Options_Price12.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price12.TabIndex = 46;
            this.Topping_Options_Price12.Text = "5,00 kr";
            // 
            // Topping_Options_Price13
            // 
            this.Topping_Options_Price13.AutoSize = true;
            this.Topping_Options_Price13.Location = new System.Drawing.Point(636, 150);
            this.Topping_Options_Price13.Name = "Topping_Options_Price13";
            this.Topping_Options_Price13.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price13.TabIndex = 47;
            this.Topping_Options_Price13.Text = "5,00 kr";
            // 
            // Topping_Options_Price14
            // 
            this.Topping_Options_Price14.AutoSize = true;
            this.Topping_Options_Price14.Location = new System.Drawing.Point(636, 174);
            this.Topping_Options_Price14.Name = "Topping_Options_Price14";
            this.Topping_Options_Price14.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price14.TabIndex = 48;
            this.Topping_Options_Price14.Text = "5,00 kr";
            // 
            // Topping_Options_Price15
            // 
            this.Topping_Options_Price15.AutoSize = true;
            this.Topping_Options_Price15.Location = new System.Drawing.Point(636, 196);
            this.Topping_Options_Price15.Name = "Topping_Options_Price15";
            this.Topping_Options_Price15.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price15.TabIndex = 49;
            this.Topping_Options_Price15.Text = "5,00 kr";
            // 
            // Topping_Options_Price16
            // 
            this.Topping_Options_Price16.AutoSize = true;
            this.Topping_Options_Price16.Location = new System.Drawing.Point(636, 219);
            this.Topping_Options_Price16.Name = "Topping_Options_Price16";
            this.Topping_Options_Price16.Size = new System.Drawing.Size(46, 13);
            this.Topping_Options_Price16.TabIndex = 50;
            this.Topping_Options_Price16.Text = "10,00 kr";
            // 
            // Topping_Options_Price17
            // 
            this.Topping_Options_Price17.AutoSize = true;
            this.Topping_Options_Price17.Location = new System.Drawing.Point(636, 242);
            this.Topping_Options_Price17.Name = "Topping_Options_Price17";
            this.Topping_Options_Price17.Size = new System.Drawing.Size(46, 13);
            this.Topping_Options_Price17.TabIndex = 51;
            this.Topping_Options_Price17.Text = "10,00 kr";
            // 
            // Topping_Options_Price18
            // 
            this.Topping_Options_Price18.AutoSize = true;
            this.Topping_Options_Price18.Location = new System.Drawing.Point(636, 265);
            this.Topping_Options_Price18.Name = "Topping_Options_Price18";
            this.Topping_Options_Price18.Size = new System.Drawing.Size(46, 13);
            this.Topping_Options_Price18.TabIndex = 52;
            this.Topping_Options_Price18.Text = "10,00 kr";
            // 
            // Topping_Options_Price19
            // 
            this.Topping_Options_Price19.AutoSize = true;
            this.Topping_Options_Price19.Location = new System.Drawing.Point(636, 288);
            this.Topping_Options_Price19.Name = "Topping_Options_Price19";
            this.Topping_Options_Price19.Size = new System.Drawing.Size(46, 13);
            this.Topping_Options_Price19.TabIndex = 53;
            this.Topping_Options_Price19.Text = "10,00 kr";
            // 
            // Topping_Options_Price20
            // 
            this.Topping_Options_Price20.AutoSize = true;
            this.Topping_Options_Price20.Location = new System.Drawing.Point(636, 311);
            this.Topping_Options_Price20.Name = "Topping_Options_Price20";
            this.Topping_Options_Price20.Size = new System.Drawing.Size(40, 13);
            this.Topping_Options_Price20.TabIndex = 54;
            this.Topping_Options_Price20.Text = "5,00 kr";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(12, 171);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price11);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price10);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price9);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price8);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Header_Label);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price20);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price7);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price6);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price19);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price5);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options12);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price4);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price18);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price3);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options11);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price2);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price17);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price1);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options13);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options10);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price16);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options9);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options14);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options8);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options7);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price15);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options6);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options15);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options5);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price14);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options4);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options16);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options3);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price13);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options2);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options17);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options1);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options_Price12);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options18);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options19);
            this.splitContainer1.Panel1.Controls.Add(this.Topping_Options20);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.splitContainer1.Panel2.Controls.Add(this.Order_Ingredients_Label);
            this.splitContainer1.Panel2.Controls.Add(this.Checkout_Header_Label);
            this.splitContainer1.Panel2.Controls.Add(this.Price_In_Total_Numbers_Label);
            this.splitContainer1.Panel2.Controls.Add(this.Done_Selecting_Button);
            this.splitContainer1.Panel2.Controls.Add(this.Price_In_Total_Label);
            this.splitContainer1.Size = new System.Drawing.Size(1114, 521);
            this.splitContainer1.SplitterDistance = 742;
            this.splitContainer1.TabIndex = 55;
            // 
            // Order_Ingredients_Label
            // 
            this.Order_Ingredients_Label.AutoSize = true;
            this.Order_Ingredients_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Order_Ingredients_Label.Location = new System.Drawing.Point(122, 79);
            this.Order_Ingredients_Label.Name = "Order_Ingredients_Label";
            this.Order_Ingredients_Label.Size = new System.Drawing.Size(51, 20);
            this.Order_Ingredients_Label.TabIndex = 36;
            this.Order_Ingredients_Label.Text = "label1";
            // 
            // Checkout_Header_Label
            // 
            this.Checkout_Header_Label.AutoSize = true;
            this.Checkout_Header_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Checkout_Header_Label.Location = new System.Drawing.Point(121, 25);
            this.Checkout_Header_Label.Name = "Checkout_Header_Label";
            this.Checkout_Header_Label.Size = new System.Drawing.Size(166, 29);
            this.Checkout_Header_Label.TabIndex = 35;
            this.Checkout_Header_Label.Text = "Din bestilling";
            // 
            // Ingredients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1126, 693);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.Thickness_RButton1);
            this.Controls.Add(this.Thickness_RButton3);
            this.Controls.Add(this.Thickness_RButton2);
            this.Controls.Add(this.Chosen_Pizza_Name_Label);
            this.Controls.Add(this.Chosen_Pizza_Description_Label);
            this.Controls.Add(this.Options_Header_Label);
            this.Controls.Add(this.Thickness_Options_Header);
            this.Controls.Add(this.Chosen_Pizza_Number_Label);
            this.Name = "Ingredients";
            this.Text = "Ingredients";
            this.Load += new System.EventHandler(this.Ingredients_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Options_Header_Label;
        private System.Windows.Forms.Label Thickness_Options_Header;
        private System.Windows.Forms.Label Topping_Options_Header_Label;
        private System.Windows.Forms.Label Chosen_Pizza_Number_Label;
        private System.Windows.Forms.Label Chosen_Pizza_Description_Label;
        private System.Windows.Forms.Label Chosen_Pizza_Name_Label;
        private System.Windows.Forms.RadioButton Thickness_RButton2;
        private System.Windows.Forms.RadioButton Thickness_RButton3;
        private System.Windows.Forms.RadioButton Thickness_RButton1;
        private System.Windows.Forms.CheckBox Topping_Options1;
        private System.Windows.Forms.CheckBox Topping_Options2;
        private System.Windows.Forms.CheckBox Topping_Options3;
        private System.Windows.Forms.CheckBox Topping_Options4;
        private System.Windows.Forms.CheckBox Topping_Options5;
        private System.Windows.Forms.CheckBox Topping_Options6;
        private System.Windows.Forms.CheckBox Topping_Options7;
        private System.Windows.Forms.CheckBox Topping_Options8;
        private System.Windows.Forms.CheckBox Topping_Options9;
        private System.Windows.Forms.CheckBox Topping_Options10;
        private System.Windows.Forms.CheckBox Topping_Options11;
        private System.Windows.Forms.CheckBox Topping_Options12;
        private System.Windows.Forms.CheckBox Topping_Options13;
        private System.Windows.Forms.CheckBox Topping_Options14;
        private System.Windows.Forms.CheckBox Topping_Options15;
        private System.Windows.Forms.CheckBox Topping_Options16;
        private System.Windows.Forms.CheckBox Topping_Options17;
        private System.Windows.Forms.CheckBox Topping_Options18;
        private System.Windows.Forms.CheckBox Topping_Options19;
        private System.Windows.Forms.CheckBox Topping_Options20;
        private System.Windows.Forms.Button Done_Selecting_Button;
        private System.Windows.Forms.Label Price_In_Total_Label;
        private System.Windows.Forms.Label Price_In_Total_Numbers_Label;
        private System.Windows.Forms.Label Topping_Options_Price1;
        private System.Windows.Forms.Label Topping_Options_Price2;
        private System.Windows.Forms.Label Topping_Options_Price3;
        private System.Windows.Forms.Label Topping_Options_Price4;
        private System.Windows.Forms.Label Topping_Options_Price5;
        private System.Windows.Forms.Label Topping_Options_Price6;
        private System.Windows.Forms.Label Topping_Options_Price7;
        private System.Windows.Forms.Label Topping_Options_Price8;
        private System.Windows.Forms.Label Topping_Options_Price9;
        private System.Windows.Forms.Label Topping_Options_Price10;
        private System.Windows.Forms.Label Topping_Options_Price11;
        private System.Windows.Forms.Label Topping_Options_Price12;
        private System.Windows.Forms.Label Topping_Options_Price13;
        private System.Windows.Forms.Label Topping_Options_Price14;
        private System.Windows.Forms.Label Topping_Options_Price15;
        private System.Windows.Forms.Label Topping_Options_Price16;
        private System.Windows.Forms.Label Topping_Options_Price17;
        private System.Windows.Forms.Label Topping_Options_Price18;
        private System.Windows.Forms.Label Topping_Options_Price19;
        private System.Windows.Forms.Label Topping_Options_Price20;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label Checkout_Header_Label;
        private System.Windows.Forms.Label Order_Ingredients_Label;
    }
}