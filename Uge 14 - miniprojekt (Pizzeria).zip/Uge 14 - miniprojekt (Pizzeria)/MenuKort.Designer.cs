﻿namespace Uge_14___miniprojekt__Pizzeria_
{
    partial class MenuKort
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pizza_Name1 = new System.Windows.Forms.Label();
            this.Pizza_Name3 = new System.Windows.Forms.Label();
            this.Pizza_Name2 = new System.Windows.Forms.Label();
            this.Number_2 = new System.Windows.Forms.Label();
            this.Number_1 = new System.Windows.Forms.Label();
            this.Number_3 = new System.Windows.Forms.Label();
            this.Price_Normal_Header = new System.Windows.Forms.Label();
            this.Pizza_Description1 = new System.Windows.Forms.Label();
            this.Pizza_Description2 = new System.Windows.Forms.Label();
            this.Pizza_Description3 = new System.Windows.Forms.Label();
            this.Price_Family_Header = new System.Windows.Forms.Label();
            this.Basket_Label = new System.Windows.Forms.Label();
            this.Basket_Content_Label = new System.Windows.Forms.Label();
            this.Basket_Content_Label2 = new System.Windows.Forms.Label();
            this.Basket_Content_Label3 = new System.Windows.Forms.Label();
            this.Number_4 = new System.Windows.Forms.Label();
            this.Pizza_Name4 = new System.Windows.Forms.Label();
            this.Pizza_Description4 = new System.Windows.Forms.Label();
            this.PriceRegular1 = new System.Windows.Forms.RadioButton();
            this.PriceRegular2 = new System.Windows.Forms.RadioButton();
            this.PriceRegular3 = new System.Windows.Forms.RadioButton();
            this.PriceRegular4 = new System.Windows.Forms.RadioButton();
            this.PriceFam1 = new System.Windows.Forms.RadioButton();
            this.PriceFam2 = new System.Windows.Forms.RadioButton();
            this.PriceFam3 = new System.Windows.Forms.RadioButton();
            this.PriceFam4 = new System.Windows.Forms.RadioButton();
            this.Select_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Pizza_Name1
            // 
            this.Pizza_Name1.AutoSize = true;
            this.Pizza_Name1.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Name1.Location = new System.Drawing.Point(223, 139);
            this.Pizza_Name1.Name = "Pizza_Name1";
            this.Pizza_Name1.Size = new System.Drawing.Size(107, 25);
            this.Pizza_Name1.TabIndex = 0;
            this.Pizza_Name1.Text = "Margherita";
            // 
            // Pizza_Name3
            // 
            this.Pizza_Name3.AutoSize = true;
            this.Pizza_Name3.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Name3.Location = new System.Drawing.Point(223, 278);
            this.Pizza_Name3.Name = "Pizza_Name3";
            this.Pizza_Name3.Size = new System.Drawing.Size(99, 25);
            this.Pizza_Name3.TabIndex = 1;
            this.Pizza_Name3.Text = "Prosciutto";
            // 
            // Pizza_Name2
            // 
            this.Pizza_Name2.AutoSize = true;
            this.Pizza_Name2.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Name2.Location = new System.Drawing.Point(223, 199);
            this.Pizza_Name2.Name = "Pizza_Name2";
            this.Pizza_Name2.Size = new System.Drawing.Size(70, 25);
            this.Pizza_Name2.TabIndex = 2;
            this.Pizza_Name2.Text = "Hawaii";
            // 
            // Number_2
            // 
            this.Number_2.AutoSize = true;
            this.Number_2.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Number_2.Location = new System.Drawing.Point(172, 199);
            this.Number_2.Name = "Number_2";
            this.Number_2.Size = new System.Drawing.Size(26, 25);
            this.Number_2.TabIndex = 3;
            this.Number_2.Text = "2.";
            // 
            // Number_1
            // 
            this.Number_1.AutoSize = true;
            this.Number_1.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Number_1.Location = new System.Drawing.Point(172, 139);
            this.Number_1.Name = "Number_1";
            this.Number_1.Size = new System.Drawing.Size(26, 25);
            this.Number_1.TabIndex = 4;
            this.Number_1.Text = "1.";
            // 
            // Number_3
            // 
            this.Number_3.AutoSize = true;
            this.Number_3.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Number_3.Location = new System.Drawing.Point(172, 278);
            this.Number_3.Name = "Number_3";
            this.Number_3.Size = new System.Drawing.Size(26, 25);
            this.Number_3.TabIndex = 5;
            this.Number_3.Text = "3.";
            // 
            // Price_Normal_Header
            // 
            this.Price_Normal_Header.AutoSize = true;
            this.Price_Normal_Header.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_Normal_Header.Location = new System.Drawing.Point(375, 100);
            this.Price_Normal_Header.Name = "Price_Normal_Header";
            this.Price_Normal_Header.Size = new System.Drawing.Size(51, 25);
            this.Price_Normal_Header.TabIndex = 6;
            this.Price_Normal_Header.Text = "Alm.";
            // 
            // Pizza_Description1
            // 
            this.Pizza_Description1.AutoSize = true;
            this.Pizza_Description1.Font = new System.Drawing.Font("Malgun Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Description1.Location = new System.Drawing.Point(224, 164);
            this.Pizza_Description1.Name = "Pizza_Description1";
            this.Pizza_Description1.Size = new System.Drawing.Size(133, 19);
            this.Pizza_Description1.TabIndex = 7;
            this.Pizza_Description1.Text = "Med tomat og ost";
            // 
            // Pizza_Description2
            // 
            this.Pizza_Description2.AutoSize = true;
            this.Pizza_Description2.Font = new System.Drawing.Font("Malgun Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Description2.Location = new System.Drawing.Point(224, 224);
            this.Pizza_Description2.Name = "Pizza_Description2";
            this.Pizza_Description2.Size = new System.Drawing.Size(154, 38);
            this.Pizza_Description2.TabIndex = 8;
            this.Pizza_Description2.Text = "Med tomat, ost, \r\nskinkekød og ananas";
            // 
            // Pizza_Description3
            // 
            this.Pizza_Description3.AutoSize = true;
            this.Pizza_Description3.Font = new System.Drawing.Font("Malgun Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Description3.Location = new System.Drawing.Point(224, 303);
            this.Pizza_Description3.Name = "Pizza_Description3";
            this.Pizza_Description3.Size = new System.Drawing.Size(119, 38);
            this.Pizza_Description3.TabIndex = 9;
            this.Pizza_Description3.Text = "Med tomat, ost \r\nog permaskinke";
            // 
            // Price_Family_Header
            // 
            this.Price_Family_Header.AutoSize = true;
            this.Price_Family_Header.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_Family_Header.Location = new System.Drawing.Point(457, 100);
            this.Price_Family_Header.Name = "Price_Family_Header";
            this.Price_Family_Header.Size = new System.Drawing.Size(52, 25);
            this.Price_Family_Header.TabIndex = 10;
            this.Price_Family_Header.Text = "Fam.";
            // 
            // Basket_Label
            // 
            this.Basket_Label.AutoSize = true;
            this.Basket_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Basket_Label.Location = new System.Drawing.Point(846, 77);
            this.Basket_Label.Name = "Basket_Label";
            this.Basket_Label.Size = new System.Drawing.Size(147, 26);
            this.Basket_Label.TabIndex = 26;
            this.Basket_Label.Text = "Indkøbskurv:";
            // 
            // Basket_Content_Label
            // 
            this.Basket_Content_Label.AutoSize = true;
            this.Basket_Content_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Basket_Content_Label.Location = new System.Drawing.Point(889, 111);
            this.Basket_Content_Label.Name = "Basket_Content_Label";
            this.Basket_Content_Label.Size = new System.Drawing.Size(0, 20);
            this.Basket_Content_Label.TabIndex = 27;
            // 
            // Basket_Content_Label2
            // 
            this.Basket_Content_Label2.AutoSize = true;
            this.Basket_Content_Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Basket_Content_Label2.Location = new System.Drawing.Point(889, 144);
            this.Basket_Content_Label2.Name = "Basket_Content_Label2";
            this.Basket_Content_Label2.Size = new System.Drawing.Size(0, 20);
            this.Basket_Content_Label2.TabIndex = 28;
            // 
            // Basket_Content_Label3
            // 
            this.Basket_Content_Label3.AutoSize = true;
            this.Basket_Content_Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Basket_Content_Label3.Location = new System.Drawing.Point(889, 176);
            this.Basket_Content_Label3.Name = "Basket_Content_Label3";
            this.Basket_Content_Label3.Size = new System.Drawing.Size(0, 20);
            this.Basket_Content_Label3.TabIndex = 29;
            // 
            // Number_4
            // 
            this.Number_4.AutoSize = true;
            this.Number_4.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Number_4.Location = new System.Drawing.Point(172, 353);
            this.Number_4.Name = "Number_4";
            this.Number_4.Size = new System.Drawing.Size(26, 25);
            this.Number_4.TabIndex = 30;
            this.Number_4.Text = "4.";
            // 
            // Pizza_Name4
            // 
            this.Pizza_Name4.AutoSize = true;
            this.Pizza_Name4.Font = new System.Drawing.Font("Malgun Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Name4.Location = new System.Drawing.Point(223, 353);
            this.Pizza_Name4.Name = "Pizza_Name4";
            this.Pizza_Name4.Size = new System.Drawing.Size(142, 25);
            this.Pizza_Name4.TabIndex = 31;
            this.Pizza_Name4.Text = "Din egen pizza";
            // 
            // Pizza_Description4
            // 
            this.Pizza_Description4.AutoSize = true;
            this.Pizza_Description4.Font = new System.Drawing.Font("Malgun Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pizza_Description4.Location = new System.Drawing.Point(224, 378);
            this.Pizza_Description4.Name = "Pizza_Description4";
            this.Pizza_Description4.Size = new System.Drawing.Size(157, 57);
            this.Pizza_Description4.TabIndex = 32;
            this.Pizza_Description4.Text = "Med tomat, ost \r\nog op til \r\n5 valgfri ingredienser";
            // 
            // PriceRegular1
            // 
            this.PriceRegular1.AutoSize = true;
            this.PriceRegular1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceRegular1.Location = new System.Drawing.Point(380, 144);
            this.PriceRegular1.Name = "PriceRegular1";
            this.PriceRegular1.Size = new System.Drawing.Size(55, 21);
            this.PriceRegular1.TabIndex = 36;
            this.PriceRegular1.TabStop = true;
            this.PriceRegular1.Text = "75 ,-";
            this.PriceRegular1.UseVisualStyleBackColor = true;
            // 
            // PriceRegular2
            // 
            this.PriceRegular2.AutoSize = true;
            this.PriceRegular2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceRegular2.Location = new System.Drawing.Point(380, 204);
            this.PriceRegular2.Name = "PriceRegular2";
            this.PriceRegular2.Size = new System.Drawing.Size(55, 21);
            this.PriceRegular2.TabIndex = 37;
            this.PriceRegular2.TabStop = true;
            this.PriceRegular2.Text = "75 ,-";
            this.PriceRegular2.UseVisualStyleBackColor = true;
            // 
            // PriceRegular3
            // 
            this.PriceRegular3.AutoSize = true;
            this.PriceRegular3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceRegular3.Location = new System.Drawing.Point(380, 283);
            this.PriceRegular3.Name = "PriceRegular3";
            this.PriceRegular3.Size = new System.Drawing.Size(55, 21);
            this.PriceRegular3.TabIndex = 38;
            this.PriceRegular3.TabStop = true;
            this.PriceRegular3.Text = "75 ,-";
            this.PriceRegular3.UseVisualStyleBackColor = true;
            // 
            // PriceRegular4
            // 
            this.PriceRegular4.AutoSize = true;
            this.PriceRegular4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceRegular4.Location = new System.Drawing.Point(380, 358);
            this.PriceRegular4.Name = "PriceRegular4";
            this.PriceRegular4.Size = new System.Drawing.Size(55, 21);
            this.PriceRegular4.TabIndex = 39;
            this.PriceRegular4.TabStop = true;
            this.PriceRegular4.Text = "75 ,-";
            this.PriceRegular4.UseVisualStyleBackColor = true;
            // 
            // PriceFam1
            // 
            this.PriceFam1.AutoSize = true;
            this.PriceFam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceFam1.Location = new System.Drawing.Point(462, 144);
            this.PriceFam1.Name = "PriceFam1";
            this.PriceFam1.Size = new System.Drawing.Size(63, 21);
            this.PriceFam1.TabIndex = 40;
            this.PriceFam1.TabStop = true;
            this.PriceFam1.Text = "125 ,-";
            this.PriceFam1.UseVisualStyleBackColor = true;
            // 
            // PriceFam2
            // 
            this.PriceFam2.AutoSize = true;
            this.PriceFam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceFam2.Location = new System.Drawing.Point(462, 204);
            this.PriceFam2.Name = "PriceFam2";
            this.PriceFam2.Size = new System.Drawing.Size(63, 21);
            this.PriceFam2.TabIndex = 41;
            this.PriceFam2.TabStop = true;
            this.PriceFam2.Text = "125 ,-";
            this.PriceFam2.UseVisualStyleBackColor = true;
            // 
            // PriceFam3
            // 
            this.PriceFam3.AutoSize = true;
            this.PriceFam3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceFam3.Location = new System.Drawing.Point(462, 283);
            this.PriceFam3.Name = "PriceFam3";
            this.PriceFam3.Size = new System.Drawing.Size(63, 21);
            this.PriceFam3.TabIndex = 42;
            this.PriceFam3.TabStop = true;
            this.PriceFam3.Text = "125 ,-";
            this.PriceFam3.UseVisualStyleBackColor = true;
            // 
            // PriceFam4
            // 
            this.PriceFam4.AutoSize = true;
            this.PriceFam4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceFam4.Location = new System.Drawing.Point(462, 358);
            this.PriceFam4.Name = "PriceFam4";
            this.PriceFam4.Size = new System.Drawing.Size(63, 21);
            this.PriceFam4.TabIndex = 43;
            this.PriceFam4.TabStop = true;
            this.PriceFam4.Text = "125 ,-";
            this.PriceFam4.UseVisualStyleBackColor = true;
            // 
            // Select_Button
            // 
            this.Select_Button.Location = new System.Drawing.Point(582, 164);
            this.Select_Button.Name = "Select_Button";
            this.Select_Button.Size = new System.Drawing.Size(190, 202);
            this.Select_Button.TabIndex = 44;
            this.Select_Button.Text = "Vælg";
            this.Select_Button.UseVisualStyleBackColor = true;
            this.Select_Button.Click += new System.EventHandler(this.Select_Button_Click);
            // 
            // MenuKort
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 559);
            this.Controls.Add(this.Select_Button);
            this.Controls.Add(this.PriceFam4);
            this.Controls.Add(this.PriceFam3);
            this.Controls.Add(this.PriceFam2);
            this.Controls.Add(this.PriceFam1);
            this.Controls.Add(this.PriceRegular4);
            this.Controls.Add(this.PriceRegular3);
            this.Controls.Add(this.PriceRegular2);
            this.Controls.Add(this.PriceRegular1);
            this.Controls.Add(this.Pizza_Description4);
            this.Controls.Add(this.Pizza_Name4);
            this.Controls.Add(this.Number_4);
            this.Controls.Add(this.Basket_Content_Label3);
            this.Controls.Add(this.Basket_Content_Label2);
            this.Controls.Add(this.Basket_Content_Label);
            this.Controls.Add(this.Basket_Label);
            this.Controls.Add(this.Price_Family_Header);
            this.Controls.Add(this.Pizza_Description3);
            this.Controls.Add(this.Pizza_Description2);
            this.Controls.Add(this.Pizza_Description1);
            this.Controls.Add(this.Price_Normal_Header);
            this.Controls.Add(this.Number_3);
            this.Controls.Add(this.Number_1);
            this.Controls.Add(this.Number_2);
            this.Controls.Add(this.Pizza_Name2);
            this.Controls.Add(this.Pizza_Name3);
            this.Controls.Add(this.Pizza_Name1);
            this.Name = "MenuKort";
            this.Text = "MenuKort";
            this.Load += new System.EventHandler(this.MenuKort_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Pizza_Name1;
        private System.Windows.Forms.Label Pizza_Name3;
        private System.Windows.Forms.Label Pizza_Name2;
        private System.Windows.Forms.Label Number_2;
        private System.Windows.Forms.Label Number_1;
        private System.Windows.Forms.Label Number_3;
        private System.Windows.Forms.Label Price_Normal_Header;
        private System.Windows.Forms.Label Pizza_Description1;
        private System.Windows.Forms.Label Pizza_Description2;
        private System.Windows.Forms.Label Pizza_Description3;
        private System.Windows.Forms.Label Price_Family_Header;
        private System.Windows.Forms.Label Basket_Label;
        private System.Windows.Forms.Label Basket_Content_Label;
        private System.Windows.Forms.Label Basket_Content_Label2;
        private System.Windows.Forms.Label Basket_Content_Label3;
        private System.Windows.Forms.Label Number_4;
        private System.Windows.Forms.Label Pizza_Name4;
        private System.Windows.Forms.Label Pizza_Description4;
        private System.Windows.Forms.RadioButton PriceRegular1;
        private System.Windows.Forms.RadioButton PriceRegular2;
        private System.Windows.Forms.RadioButton PriceRegular3;
        private System.Windows.Forms.RadioButton PriceRegular4;
        private System.Windows.Forms.RadioButton PriceFam1;
        private System.Windows.Forms.RadioButton PriceFam2;
        private System.Windows.Forms.RadioButton PriceFam3;
        private System.Windows.Forms.RadioButton PriceFam4;
        private System.Windows.Forms.Button Select_Button;
    }
}